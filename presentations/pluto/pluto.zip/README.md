## README
This contains some resources to get started with Pluto.jl
- start here: [GitHub](https://github.com/fonsp/Pluto.jl/)
- [Official Readme](https://juliahub.com/docs/Pluto/OJqMt/0.7.4/)
- [MIT Course on Computational Thinking with Julia](https://computationalthinking.mit.edu/Fall20/)
- [Binder](https://hub.gke2.mybinder.org/user/fonsp-pluto-on-binder-tt7zur5m/pluto/sample) (for the skeptics!)
