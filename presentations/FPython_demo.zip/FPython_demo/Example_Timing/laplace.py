import numpy as np
import time

# f2py version
from laplace_fortran import f90_update

# ctypes version
import ctypes as C
from numpy.ctypeslib import ndpointer
_cfunc = np.ctypeslib.load_library('laplace_C', '.')
_cfunc.C_update.restype = C.c_int
_cfunc.C_update.argtypes = [ndpointer(C.c_double, flags="C_CONTIGUOUS"),
                            C.c_int, C.c_int,
                            C.c_double, C.c_double]
# ctypes fortran version
#_ffunc = np.ctypeslib.load_library('laplace_fortran03', '.')
#_ffunc.f03.restype = C.c_int
#_ffunc.f03_update.argtypes = [ndpointer(C.c_double, flags="F_CONTIGUOUS"),
                            #C.c_int, C.c_int,
                            #C.c_double, C.c_double]

# cffi version
from cffi import FFI
ffi = FFI()
lib = ffi.dlopen('./laplace_C.so')
ffi.cdef('''
         int C_update(double *iarray, int ilen, int jlen, double dx2, double dy2);
         ''')

dx = 0.1
dy = 0.1
dx2 = dx*dx
dy2 = dy*dy

# pure python (the wrong way) method
def py_update(u):
    nx, ny = u.shape
    for i in range(1,nx-1):
        for j in range(1, ny-1):
            u[i,j] = ((u[i+1, j] + u[i-1, j]) * dy2 +
                      (u[i, j+1] + u[i, j-1]) * dx2) / (2*(dx2+dy2))

# numpy method -- this is actually a Jacobi iteration, not G-S. 
def num_update(u):
    u[1:-1,1:-1] = ((u[2:,1:-1]+u[:-2,1:-1])*dy2 + 
                    (u[1:-1,2:] + u[1:-1,:-2])*dx2) / (2*(dx2+dy2))



# ctypes wrapper 
def ctypes_update(u):
    return _cfunc.C_update(u, C.c_int(u.shape[0]), C.c_int(u.shape[1]),
                           dx2, dy2)

# ctypes wrapper fortran
#def ctypes_fupdate(u):
    #return _ffunc.f03_update(u, C.c_int(u.shape[0]), C.c_int(u.shape[1]),
                           #dx2, dy2)

# cffi wrapper
def cffi_update(u):
    pu = ffi.cast("double *", u.ctypes.data)
    return lib.C_update(pu, u.shape[0], u.shape[1], dx2, dy2)

# driver 
def calc(N, Niter=100, func=py_update, args=(), order="C"):
    u = np.zeros([N, N], dtype=np.float64, order=order)
    u[0] = 1   # boundary condition
    for i in range(Niter):
        func(u,*args)
    return u

N = 80
iters = 10000

# pure python
start = time.time()
res_py = calc(N, Niter=iters)
print('python: {} s'.format(time.time()-start))

## NumPy
#start = time.time()
#res_np = calc(N, Niter=iters, func=num_update)
#print('NumPy: {} s'.format(time.time()-start))

# f2py 
start = time.time()
res_f90 = calc(N, Niter=iters, func=f90_update, 
              args=(N, N, dx2, dy2), order="F")
print('f2py: {} s'.format(time.time()-start))

# ctypes
start = time.time()
res_ctypes = calc(N, Niter=iters, func=ctypes_update)
print('ctypes: {} s'.format(time.time()-start))

# cffi
start = time.time()
res_cffi = calc(N, Niter=iters, func=cffi_update)
print('cffi: {} s'.format(time.time()-start))

# ctypes fortran
#start = time.time()
#res_03 = np.zeros([N,N])
#res_03[0] = 1
#for i in range(iters):
    #_ffunc.f03(res_03, N, N, dx2, dy2)
#res_03 = calc(N, Niter=iters, func=ctypes_fupdate)
#print "ctypes fortran: {} s".format(time.time()-start)
