import numpy as np

import lapack

# Solve a linear system A*x = b
A = np.array([[1,2],[3,4]])
b = np.array([[5],[6]], np.float64, order='F')

# see dgesv.__doc__
print (lapack.dgesv.__doc__)
lapack.dgesv(2,1,A,[0,0],b,0)
print (b)
