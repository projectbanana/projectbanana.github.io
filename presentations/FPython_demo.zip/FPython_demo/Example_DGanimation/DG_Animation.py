import matplotlib
matplotlib.use('Qt4Agg')
#matplotlib.use('TkAgg')
import time
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.gridspec as gridspec

import DG_linear

n = 16 
k = 2
cfl = 0.1**k
#final_time = 1.2
x = np.zeros((n), dtype=np.float64, order='F')
dx = np.zeros((n), dtype=np.float64, order='F')
u = np.zeros((k+1,n), dtype=np.float64, order='F')
P = np.zeros((k+1,k+1), dtype=np.float64, order='F')

# show element n0 - n0 + i0
i0 = 4
n0 = 6

# animation
DG_linear.dg.init(n,k,x,dx,u,P)

fig, axes = plt.subplots(ncols=2, figsize=(12,6), dpi=120)


axes[0].text(0.36,0.8, r'$k = 2,\, N = 16$', fontsize=18)
radau = np.array([-0.6898979485566356, 0.2898979485566355, 1])
xj = np.zeros(i0*(k+1))
yj = np.zeros(xj.size)
for j in range(i0):
    for i in range(k+1):
        xj[j*(k+1)+i] = x[n0+j-1] + 0.5*dx[n0+j-1]*radau[i]
axes[1].plot(xj,yj,'ro')
axes[1].text(x[n0-1],0.0008, r'Superconvergenct at Radau Points', fontsize=15)

# set the axis 
axes[0].set_title(r'DG solution: $u_h$')
axes[0].set_xlabel('x')
axes[0].set_xlim(0,1)
axes[0].set_ylim(-1,1)
axes[1].set_title(r'error: $u-u_h$ on %sth ~ %sth elements'%(n0,n0+i0-1))
axes[1].set_xlabel('x')
axes[1].set_xlim(x[n0-1]-0.5*dx[n0-1], \
                 x[n0+i0-2]+0.5*dx[n0+i0-2])
axes[1].set_ylim(-0.001,0.001)
axes[1].set_yticks((-0.001,0,0.001))
axes[1].set_yticklabels(('-1e-3','0','1e-3'))

for i in range(i0):
    axes = np.append(axes, axes[1])
plt.tight_layout()
t = 0.
dt = cfl/16
styles = ['k-', 'g-', 'y-', 'm-', 'b-', 'c-']

def plot(ax, style, j):
    return ax.plot([], [], style, animated=True, lw=3)[0]
lines = [plot(ax, style, j) for ax, style, j in zip(axes, styles, range(5))]

#DG_linear.dg.init(n,k,x,dx,u,P)
def animate(i):
    global t
    DG_linear.dg.rk3(n, k, dt, dx, u, P)
    t = t + dt
    for j, line in enumerate(lines, start=0):
        if j == 0:
            xj = np.linspace(1.e-10, 1, 100, endpoint=False)
            yj = np.zeros(xj.size)
            err = np.zeros(xj.size)
            DG_linear.dg.dg_eval2(n, k, t, x, dx, u, xj, yj, err)            
            line.set_data(xj,yj)
        else:
            xj = np.linspace(x[n0+j-2]-0.5*dx[n0+j-2]+1.e-10, \
                             #x[n0+j-2]+0.5*dx[n0+j-2], 20, \
                             x[n0+j-2]+0.5*dx[n0+j-2]-1.e-10, 20)
                             #endpoint=False)
            yj = np.zeros(xj.size)
            err = np.zeros(xj.size)
            DG_linear.dg.dg_eval2(n, k, t, x, dx, u, xj, yj, err)            
            line.set_data(xj,err)
        #line.set_ydata(np.sin(2.*np.pi*(j*x + i/10.0)))
        #print (i)
        #if (i % 8 == 0) and (i <= 1600):
            #plt.savefig('movie_'+str(int(i/8))+'.png')
            #plt.savefig('movie_'+str(int(i/8)).zfill(4)+'.png')
    return lines

# We'd normally specify a reasonable "interval" here...
ani = animation.FuncAnimation(fig, animate, range(1600), 
                              interval=0, blit=True)
#ani.save('DG_Adjerid.mp4', fps=30)
#ani.save('DG_Adjerid.mp4', fps=30, extra_args=['-vcodec', \
                                                   #'libx264'])
plt.show()

