// Copyright 2021 Alexander Heinlein
// Contact: Alexander Heinlein (a.heinlein@tudelft.nl)

// std
#include <iostream>
#include <fstream>

// Tpetra
#include <Tpetra_Core.hpp>
#include <Tpetra_CrsMatrix.hpp>
#include <Tpetra_Map.hpp>
#include <Tpetra_MultiVector.hpp>
#include <Tpetra_Vector.hpp>
#include <Tpetra_Version.hpp>
#include <Teuchos_Array.hpp>
#include <Teuchos_ScalarTraits.hpp>
#include <Teuchos_RCP.hpp>

// Teuchos
#include <Teuchos_Array.hpp>
#include <Teuchos_CommandLineProcessor.hpp>
// #include <Teuchos_FancyOStream.hpp>
#include <Teuchos_RCP.hpp>
#include <Teuchos_ScalarTraits.hpp>
// #include <Teuchos_VerboseObject.hpp>

// Belos
#include <BelosLinearProblem.hpp>
#include <BelosPseudoBlockGmresSolMgr.hpp>
#include <BelosTpetraAdapter.hpp>

int main (int argc, char *argv[])
{
    using namespace Belos;
    using namespace std;
    using namespace Teuchos;
    using namespace Tpetra;

    using Teuchos::tuple;
    using Tpetra::Operator;

    typedef Map<> map_type;
    typedef MultiVector<> vector_type;
    typedef vector_type::scalar_type scalar_type;
    typedef vector_type::local_ordinal_type local_ordinal_type;
    typedef vector_type::global_ordinal_type global_ordinal_type;
    typedef vector_type::node_type node_type;
    typedef vector_type::mag_type magnitude_type;
    typedef CrsMatrix<scalar_type,local_ordinal_type,global_ordinal_type,node_type> crs_matrix_type;
    typedef Operator<scalar_type,local_ordinal_type,global_ordinal_type,node_type> operator_type;
    typedef Import<local_ordinal_type,global_ordinal_type,node_type> import_type;

    typedef LinearProblem<scalar_type,vector_type,operator_type> linear_problem_type;
    typedef PseudoBlockGmresSolMgr<scalar_type,vector_type,operator_type> solver_type;

    // Start MPI parallel scope
    ScopeGuard tpetraScope(&argc, &argv);
    {
        CommandLineProcessor clp;
        RCP<FancyOStream> out = fancyOStream(rcpFromRef(cout));

        // Get input paramaters
        int N = 5;
        clp.setOption("N",&N,"Number of elements pro MPI rank.");
        int V = 4;
        clp.setOption("V",&V,"Verbosity Level.\nVERB_DEFAULT=-1, VERB_NONE=0, \
VERB_LOW=1, VERB_MEDIUM=2, VERB_HIGH=3, VERB_EXTREME=4");
        clp.recogniseAllOptions(true);
        clp.throwExceptions(true);
        CommandLineProcessor::EParseCommandLineReturn parseReturn = clp.parse(argc,argv);
        if (parseReturn == CommandLineProcessor::PARSE_HELP_PRINTED) {
            return(EXIT_SUCCESS);
        }
        EVerbosityLevel verbosityLevel = static_cast<EVerbosityLevel>(V);

        // Get the size of the MPI communicator and the local rank
        auto comm = Tpetra::getDefaultComm ();
        const size_t myRank = comm->getRank();
        const size_t numProcs = comm->getSize();

        const bool verbose = (myRank == 0);
        if (verbose) cout << endl;
        if (verbose) cout << "+-------------------------+" << endl;
        if (verbose) cout << "| Demonstration of Tpetra |" << endl;
        if (verbose) cout << "+-------------------------+" << endl;
        if (verbose) cout << "\tNumber of MPI ranks: \t" << numProcs << endl;
        if (verbose) cout << "\tVerbose MPI rank: \t" << myRank << endl;
        if (verbose) cout << "\tParameters:" << endl;
        if (verbose) cout << "\t\tN \t=\t" << N << endl;
        if (verbose) cout << "\t\tV \t=\t" << V << endl;

        if (verbose) cout << "\nIn this example, we solve the differential \
equation\n\n\t-u'' = 1 on [0,1]\n\tu(x) = 0 for x=0 and x=1\n\non a \
grid with " << N*numProcs+2 << " points using finite differences. The \
resulting linear equation system Ax=b is then solved using the generalized \
minimal residual method (GMRES) (generalized method) as the iterative solver. \
The solution can then be plotted using 'gnuplot plot_solution.p'." << endl;

        if (verbose) cout << endl << "\
############################################################################\n\
# I. Construction of the Tpetra::Map for the parallel distribution         #\n\
############################################################################" <<
endl;

        global_ordinal_type numGblIndices = static_cast<local_ordinal_type> (numProcs*N);
        if (verbose) cout << "We neglect the boundary nodes and therefore \
create a map with " << numGblIndices << " global indices. This is exactly "
<< numProcs << "x" << N << " (= Number of MPI ranks x N). \n\nPrinting the map, \
we obtain the following output:" << endl;
        RCP<const map_type> map = rcp(new map_type(numGblIndices,0,comm));
        comm->barrier(); comm->barrier(); comm->barrier(); if (verbose) cout << "<<<" << endl;
        map->describe(*out,verbosityLevel);
        comm->barrier(); comm->barrier(); comm->barrier(); if (verbose) cout << ">>>" << endl;

        if (verbose) cout << endl << "\
############################################################################\n\
# II. Construction of a parallel Tpetra::CrsMatrix                         #\n\
############################################################################" <<
endl;

        if (verbose) cout << "In order to approximate u'' using finite \
differences, we use a three point stencil:\n\n\t1/(h^2) [-1 2 -1]\n\nHere, the \
step size h = 1/" << numGblIndices+1 << ". To assemble the system matrix using \
the three point stencil, we have to allocate space for three entries for each \
matrix row. The rows of the matrix are distributed according to the map \
created before." << endl << endl;
        RCP<crs_matrix_type> A(new crs_matrix_type(map, 3));

        const scalar_type two = static_cast<scalar_type> (2.0*(numGblIndices+1)*(numGblIndices+1));
        const scalar_type negOne = static_cast<scalar_type> (-1.0*(numGblIndices+1)*(numGblIndices+1));
        if (verbose) cout << "Each matrix row will only contain three entries \
\n\n\t " << negOne << ", " << two << ", and " << negOne << ",\n\nwhere the " <<
two << " is on the main diagonal and the two " << negOne << " entries are in \
the first off-diagonal. The matrix is assembled by looping over all local \
matrix rows on each MPI rank and inserting the three values at the correct \
global row and column indices. Therefore, the map is used to transform local\
indices into global indices." << endl << endl;
        for (local_ordinal_type lclRow = 0;
             lclRow < static_cast<local_ordinal_type> (N);
             lclRow++) {

            const global_ordinal_type gblRow = map->getGlobalElement(lclRow);

            if (gblRow == 0) {
                // cout << myRank << " - " << gblRow << " (" << lclRow << ")" << " A" << endl;
                // A(0, 0:1) = [2, -1]
                A->insertGlobalValues(gblRow,
                                      tuple<global_ordinal_type> (gblRow, gblRow + 1),
                                      tuple<scalar_type> (two, negOne));
            } else if (static_cast<global_ordinal_type> (gblRow) == numGblIndices - 1) {
                // cout << myRank << " - " << gblRow << " (" << lclRow << ")" << " B" << endl;
                // A(N-1, N-2:N-1) = [-1, 2]
                A->insertGlobalValues(gblRow,
                                      tuple<global_ordinal_type> (gblRow - 1, gblRow),
                                      tuple<scalar_type> (negOne, two));
            } else {
                // cout << myRank << " - " << gblRow << " (" << lclRow << ")" << " C" << endl;
                // A(i, i-1:i+1) = [-1, 2, -1]
                A->insertGlobalValues(gblRow,
                                      tuple<global_ordinal_type> (gblRow - 1, gblRow, gblRow + 1),
                                      tuple<scalar_type> (negOne, two, negOne));
            }

        }
        if (verbose) cout << "The assembly of the matrix is finalized with the \
call fillComplete(map,map). This call will eventually perform some \
communication to transfer matrix entries, if necessary. Furthermore, the \
matrix is stored in compressed row storage (CRS) format. The map indicates the \
domain map and the range map\n\nPrinting the matrix A, we obtain the following \
output:" << endl;
        A->fillComplete(map,map);

        comm->barrier(); comm->barrier(); comm->barrier(); if (verbose) cout << "<<<" << endl;
        A->describe(*out,verbosityLevel);
        comm->barrier(); comm->barrier(); comm->barrier(); if (verbose) cout << ">>>" << endl;

        if (verbose) cout << endl << "\
############################################################################\n\
# III. Construction of solution and right hand side vectors                #\n\
############################################################################" <<
        endl;

        if (verbose) cout << "Based on the same map, i.e., with the same \
parallel distribution, we construct the vectors for the solution and right \
hand side. The solution vector is initiazed with zero and used as an initial \
guess for the iterative solver and the right hand side is set to one.\n\nWe \
also print those two vectors. The initial guess for the solution:" << endl;
        RCP<vector_type> x (new vector_type(map,1));
        x->putScalar(0.0);
        comm->barrier(); comm->barrier(); comm->barrier(); if (verbose) cout << "<<<" << endl;
        x->describe(*out,verbosityLevel);
        comm->barrier(); comm->barrier(); comm->barrier(); if (verbose) cout << ">>>" << endl;

if (verbose) cout << endl << "The right hand side b:" << endl;
        RCP<vector_type> b (new vector_type(map,1));
        b->putScalar(1.0);
        comm->barrier(); comm->barrier(); comm->barrier(); if (verbose) cout << "<<<" << endl;
        b->describe(*out,verbosityLevel);
        comm->barrier(); comm->barrier(); comm->barrier(); if (verbose) cout << ">>>" << endl;

        if (verbose) cout << endl << "\
############################################################################\n\
# IV. Solve the linear equation system                                     #\n\
############################################################################" <<
        endl;

        if (verbose) cout << "Next, we solve the linear equation system Ax=b \
using the GMRES implementation from the Trilinos package Belos.\n\nFor the \
sake of completeness, we first set up the solver and print all solver \
parameters:" << endl;
        RCP<linear_problem_type> problem (new linear_problem_type(A,x,b));
        problem->setProblem(x,b);

        RCP<ParameterList> parameters(new ParameterList);
        parameters->set("Verbosity", Errors + Warnings + StatusTestDetails);
        parameters->set("Output Frequency", 10);
        parameters->set("Output Style", Brief);

        RCP<solver_type> solver(new solver_type(problem,parameters));
comm->barrier(); comm->barrier(); comm->barrier(); if (verbose) cout << "<<<" << endl;
        solver->getCurrentParameters()->print();
comm->barrier(); comm->barrier(); comm->barrier(); if (verbose) cout << ">>>" << endl;

if (verbose) cout << endl << "And then, we solve the system:";
        solver->solve();

if (verbose) cout << endl << "This yields the parallel solution vector:" <<
endl;
        comm->barrier(); comm->barrier(); comm->barrier(); if (verbose) cout << "<<<" << endl;
        x->describe(*out,verbosityLevel);
        comm->barrier(); comm->barrier(); comm->barrier(); if (verbose) cout << ">>>" << endl;

        if (verbose) cout << endl << "\
############################################################################\n\
# V. Test solution                                                         #\n\
############################################################################" <<
        endl;

if (verbose) cout << "In order to measure the quality of the solution, we \
additionally compute the 2-norm of the residual b-Ax. Since we do not \
need the right hand side vector b after this, we store the residual in the \
vector b." << endl << endl;

        A->apply(*x,
                 *b,
                 Teuchos::NO_TRANS,
                 static_cast<scalar_type> (-1.0),
                 static_cast<scalar_type> (1.0));
        // b->describe(*out,verbosityLevel);

        magnitude_type normRes = b->getVector(0)->norm2();

        if (verbose) cout << "Norm residual = " << normRes << endl;

        if (verbose) cout << endl << "\
############################################################################\n\
# VI. Transfer the solution to rank 0 & write it to a text file            #\n\
############################################################################" <<
        endl;

        if (verbose) cout << "Finally, to write the solution to a text file in \
an ordered way, we first transfer the solution vector to rank 0. In order to \
do so, we employ a Tpetra::Import object." << endl << endl;
        size_t myNumGblIndices = (myRank == 0 ? numGblIndices : 0 );
        RCP<const map_type> mapRank0 = rcp(new map_type(numGblIndices,myNumGblIndices,0,comm));
        RCP<vector_type> xRank0 (new vector_type(mapRank0,1));
        RCP<const import_type> importRank0 = rcp(new import_type(map,mapRank0));
        xRank0->doImport(*x,*importRank0,INSERT);

        if (verbose) cout << "This is the solution vector on rank 0:" << endl;
        comm->barrier(); comm->barrier(); comm->barrier(); if (verbose) cout << "<<<" << endl;
        xRank0->describe(*out,verbosityLevel);
        comm->barrier(); comm->barrier(); comm->barrier(); if (verbose) cout << ">>>" << endl;

        if (verbose) cout << endl << "Finally, this vector is written to the \
text file solution.txt. It can be plotted with 'gnuplot plot_solution.p'." <<
endl;
        if (myRank == 0) {
            ofstream solutionFile;
            solutionFile.open("solution.txt");
            if (solutionFile.is_open()) {
                solutionFile << 0.0 << " " << 0.0 << "\n";
                ArrayRCP<const scalar_type> xValues = xRank0->getData(0);
                for (local_ordinal_type lclRow = 0;
                lclRow < myNumGblIndices;
                lclRow++) {
                    solutionFile << (lclRow+1.0)/(numGblIndices+1.0) << " " << xValues[lclRow] << "\n";
                }
                solutionFile << 1.0 << " " << 0.0;
                solutionFile.close();
            } else cout << "Unable to open solution file.";
        }

        if (verbose) cout << endl << "Finished!" << endl;

    }
    return 0;
}
